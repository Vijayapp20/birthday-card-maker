import { useState, useEffect, lazy, Suspense } from 'react' // v2
import { Routes, Route, Navigate } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import { ParticlesProvider } from '@tsparticles/react'
import { loadSlim } from '@tsparticles/slim'
import api from './api'
import BirthdayForm from './components/BirthdayForm'
import OccasionLandingPage from './components/OccasionLandingPage'
import OccasionLinks from './components/OccasionLinks'
import { SEO_PAGE_LIST, LEGACY_REDIRECTS } from './seoContent'

// BirthdayCard pulls in three.js + vanta (~500KB) — not needed until the
// form is actually submitted, so load it on demand instead of blocking
// the initial form render. GiftBoxCard is pure CSS (no heavy deps) but is
// still lazy-loaded to keep it out of the initial bundle.
const BirthdayCard = lazy(() => import('./components/BirthdayCard'))
const GiftBoxCard  = lazy(() => import('./components/GiftBoxCard'))

// Registers the lightweight ("slim") tsparticles engine once for the whole
// app, so individual <Particles> instances (see AmbientParticles.jsx) don't
// each pay the init cost.
const initParticles = async (engine) => { await loadSlim(engine) }

const CardLoadingFallback = (
  <div style={{
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    height: '100vh', color: '#fff', fontFamily: 'sans-serif', fontSize: '1.2rem'
  }}>
    Loading your celebration card... 🎉
  </div>
)

// Shared shell for every route: handles the ?card=ID shared-view lookup,
// loading/error states, and rendering the finished card once a form
// submits. `renderForm(onStart)` supplies whatever should show before
// that — the plain form on "/", or an SEO landing page + form on an
// occasion route like "/anniversary-wishes".
function CelebrationShell({ renderForm }) {
  const [cardData, setCardData] = useState(null)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState('')
  const [isSharedView, setIsSharedView] = useState(false)

  // If the URL has ?card=ID, load that shared card instead of showing the form
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const cardId = params.get('card')
    if (!cardId) return

    setIsSharedView(true)
    setLoading(true)
    api.get(`/api/cards/${cardId}`)
      .then(res => {
        const data = res.data
        setCardData({
          recipientName: data.recipientName,
          senderName: data.senderName,
          relationship: data.relationship,
          message: data.message,
          photoUrl: data.photoUrl,
          characterGif: data.characterGif || 'g5',
          occasionType: data.occasionType || 'birthday',
          template: data.template || 'photo',
        })
      })
      .catch(() => {
        setError('This celebration card link is invalid or has expired.')
      })
      .finally(() => setLoading(false))
  }, [])

  const renderContent = () => {
    if (loading) {
      return (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          height: '100vh', color: '#fff', fontFamily: 'sans-serif', fontSize: '1.2rem'
        }}>
          Loading your celebration card... 🎉
        </div>
      )
    }

    if (error) {
      return (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          height: '100vh', color: '#fff', fontFamily: 'sans-serif', fontSize: '1.2rem',
          textAlign: 'center', padding: '0 20px'
        }}>
          ⚠️ {error}
        </div>
      )
    }

    if (cardData) {
      const onBack = isSharedView ? undefined : () => {
        // Clear any ?card=ID from the URL and go back to the form
        window.history.replaceState({}, '', window.location.pathname)
        setCardData(null)
      }
      return (
        <Suspense fallback={CardLoadingFallback}>
          {cardData.template === 'giftbox'
            ? <GiftBoxCard cardData={cardData} onBack={onBack} />
            : <BirthdayCard cardData={cardData} onBack={onBack} />}
        </Suspense>
      )
    }

    return renderForm(setCardData)
  }

  return (
    <ParticlesProvider init={initParticles}>
      {/* Shared cards hold personal photos/messages — keep them out of search results */}
      {isSharedView && (
        <Helmet>
          <meta name="robots" content="noindex, nofollow" />
        </Helmet>
      )}
      {renderContent()}
    </ParticlesProvider>
  )
}

export default function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <CelebrationShell
            renderForm={(onStart) => (
              <>
                <BirthdayForm onStart={onStart} />
                <OccasionLinks />
              </>
            )}
          />
        }
      />
      {SEO_PAGE_LIST.map(seo => (
        <Route
          key={seo.key}
          path={seo.path}
          element={
            <CelebrationShell
              renderForm={(onStart) => (
                <OccasionLandingPage seo={seo} occasionKey={seo.key} onStart={onStart} />
              )}
            />
          }
        />
      ))}
      {/* Old URLs (e.g. /new-home-wishes) — vercel.json sends the real 301 in production */}
      {Object.entries(LEGACY_REDIRECTS).map(([from, to]) => (
        <Route key={from} path={from} element={<Navigate to={to} replace />} />
      ))}
      {/* Unknown paths fall back to the home form rather than a dead 404 page */}
      <Route
        path="*"
        element={<CelebrationShell renderForm={(onStart) => <BirthdayForm onStart={onStart} />} />}
      />
    </Routes>
  )
}
